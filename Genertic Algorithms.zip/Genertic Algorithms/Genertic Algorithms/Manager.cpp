//library includes
#include <string>
#include <iostream>
#include <chrono>
#include <vector>
#include <algorithm>

//local includes
#include "Manager.h"
#include "Individual.h"

//global variable used in all classes
//set it to blank first, for user will
//input what they want in here
string target = "";

using namespace std;
//constant int for population size
const int populationSize = 100;

//creating the genes
const string genes = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOP"\
"QRSTUVWXYZ 1234567890,.-;:_!\"#%&/()=?@${[]}";

//generate a random number
//from a given range
int Manager::randomNumber(int start, int end) {
	int range = (end - start) + 1;
	int randomInt = start + (rand() % range);
	return randomInt;
}

//create random genes for mutation
//Used when there is a need for mutation
//to break up the generations so they don't
//stagnate
char Manager::mutatedGenes() {
	int len = genes.size();
	int r = randomNumber(0, len - 1);
	return genes[r];
}

//create a string of genes/chromosone
string Manager::createGenome() {

	int len = target.size();
	string genome = "";
	for (int i = 0; i < len; i++) {
		genome += mutatedGenes();
	}
	return genome;
}

// Overloading < operator
// used in the sort function
bool operator<(const Indivdual &ind1, const Indivdual &ind2)
{
	return ind1.fitness < ind2.fitness;
}

//this is the main loop of the program
//This starts everything off and launches into the
//other functions that are required to find the target string
//It will loop through until the target has been found
int Manager::mainLoop() {

	//getting user input for the target string
	cout << "Enter the word you would like to use" << endl;
	cout << "If you would like to use a sentence then please enter _ between words" << endl;
	cin >> target;

	//seeding
	srand((unsigned)(time(0)));

	//current generation
	int generation = 0;

	vector<Indivdual> population;
	//bool used to determine if the target string has been found
	bool found = false;

	//create initial popultaion equal to the population size
	for (int i = 0; i < populationSize; i++) {
		//create genes/chromosones
		string genome = createGenome();
		//add the individual to the list
		population.push_back(Indivdual(genome));
	}
	//while the target string has not been found
	while (found == false) {

		//sorts population in terms of fitness (increasing order)
		sort(population.begin(), population.end());

		//if fitness is = 0 then we have found the solution
		if (population[0].fitness <= 0) {
			found = true;
			break;
		}

		//vector for the new generation
		vector<Indivdual> newGeneration;

		//elitism, only top 10% of population goes into the next generation
		int s = (10 * populationSize) / 100;

		for (int i = 0; i < s; i++) {
			newGeneration.push_back(population[i]);
		}

		//50% of the fittest population will produce offspring
		s = (90 * populationSize) / 100;
		//this for loop goes through the mate function to produce new offspring
		//for new generations getting closer to the target string
		for (int i = 0; i < s; i++) {
			int len = population.size();
			int r = randomNumber(0, 50);
			Indivdual parent1 = population[r];
			r = randomNumber(0, 50);
			Indivdual parent2 = population[r];
			Indivdual offspring = parent1.mate(parent2);
			newGeneration.push_back(offspring);
		}

		//prints out the generations and the string we currently have
		population = newGeneration;
		cout << "Generation: " << generation << "\t";
		cout << "String: " << population[0].chromosone << "\t";
		cout << "Fitness: " << population[0].fitness << endl;
		//increase value of generation to display what generation we are up to
		generation++;

	}
	//print out the results when we have found the target string
	cout << "Generation: " << generation << "\t";
	cout << "String: " << population[0].chromosone << "\t";
	cout << "Fitness: " << population[0].fitness << "\n";

	//waits for user input to continue
	system("Pause");

	//clear the screen
	system("cls");

	//goes back to the main menu 
	userSetup();

	return 0;
}


//This is the menu function
//Lets user either quit or start
//the program to find a string that they
//desire to find
int Manager::userSetup() {

	int playerChoice = 5;

	while (playerChoice > 3) {

		cout << "Welcome to Genetic Algorithms" << endl;
		cout << "1) Start The algorithm" << endl;
		cout << "2) Quit" << endl;

		cin >> playerChoice;

		if (playerChoice == 1) {
			system("cls");
			mainLoop();
		}
		else {
			exit(0);
		}

	}
	userSetup();
	return 0;
}




