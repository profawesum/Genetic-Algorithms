#pragma once
#include "Manager.h"

#include <iostream>
#include <string>

using namespace std;

class Indivdual {

public:

	//variables
	string chromosone;
	int fitness;

	//functions
	Indivdual(string chromo);
	Indivdual mate(Indivdual parent2);
	int calculateFitness();

};
