
//Local includes
#include "Manager.h"

//reference to the manager
Manager manM;

//launches into the menu
//this is the place in which the code is
//initialised from
int main() {
	manM.userSetup();
}

