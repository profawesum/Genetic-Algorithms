#pragma once

//Library Includes
#include <iostream>
#include <string>

using namespace std;

//target string to be generated
//User can enter what they would like to see generated using only letters
//true global variable
extern string target;

class Manager {

public:

	//functions
	int randomNumber(int start, int end);
	char mutatedGenes();
	string createGenome();

	int mainLoop();
	int userSetup();

};

