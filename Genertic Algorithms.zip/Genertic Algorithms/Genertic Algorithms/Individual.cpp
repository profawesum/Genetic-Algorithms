
//library Includes
#include <iostream>
#include <string>

//local includes
#include "Individual.h"
#include "Manager.h"

//reference to the manager class
Manager man;

//constructor
Indivdual::Indivdual(string chromo) {
	//sets chromosone to the passed in value
	chromosone = chromo;
	//calculates the fitness
	fitness = calculateFitness();
}

//create the offspring
//by using the parents genes in a random
//selection, also there is the chance for
//mutation to create diversity so the genes
//won't stay the same for all the generations
Indivdual Indivdual::mate(Indivdual parent2) {

	//blank gene for child
	string child = "";

	//length
	int len = chromosone.size();

	for (int i = 0; i < len; i++) {

		//random number
		float p = float(man.randomNumber(0, 100));

		//if it is less than 0.45 insert parent 1 gene
		if (p < 45) {
			child += chromosone[i];
		}

		//if it is between 0.45 and 0.90 insert parent 2 gene
		else if (p < 90) {
			child += parent2.chromosone[i];
		}
		//otherwise mutate using a random gene
		else {
			child += man.mutatedGenes();
		}
	}

	//return the child
	return Indivdual(child);
}

//calculates the fitness value
//The value is the number of 
//characters which differ from the target
int Indivdual::calculateFitness() {

	int len = target.size();
	int fitness = 0;
	for (int i = 0; i < len; i++) {
		//if the value in chromosone is not equal to the target then increase fitness
		if (chromosone[i] != target[i]) {
			fitness++;
		}
	}
	return fitness;
}
